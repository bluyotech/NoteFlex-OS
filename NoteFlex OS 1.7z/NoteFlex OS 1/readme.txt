the NoteFlex os is still in devlopment so this is just a prototyp 
the bat file is gonna create two folders but in future updates it will create more folders
if you wanna collab on this project contact me here : https://taplink.cc/bluyo_tech