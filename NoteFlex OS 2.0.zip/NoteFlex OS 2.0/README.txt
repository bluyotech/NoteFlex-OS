     _   _       _       ______ _              ____   _____ 
    l \ l l     l l     l  ____l l            / __ \ / ____l
    l  \l l ___ l l_ ___l l__  l l _____  __ l l  l l (___  
    l . ` l/ _ \l __/ _ \  __l l l/ _ \ \/ / l l  l l\___ \ 
    l l\  l (_) l ll  __/ l    l l  __/      l l  l l ___l )
    l_l \_l\___/ \__\___l_l    l_l\___/_/\_\  \____/ l_____/ 

                                                        
           The NoteFlex OS is still in development

In this new version, there are many features like:
- HTA apps compatibility 
- GUI
- Clickable buttons (using your mouse)
- A feature to delete apps

If you want to collaborate on this project, contact me here: https://taplink.cc/bluyo_tech